<?php

$arModuleVersion = [
    "VERSION" => "3.4.6",
    "VERSION_DATE" => "2019-07-18 10:00:20",
];