<script type="text/javascript">
    <? include __DIR__ . '/script.js' ?>
</script>