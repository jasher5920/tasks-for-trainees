<style type="text/css">
    <? include __DIR__ . '/style.css' ?>
</style>