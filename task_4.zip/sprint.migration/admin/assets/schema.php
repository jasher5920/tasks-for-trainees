<script type="text/javascript">
    <? include __DIR__ . '/schema.js' ?>
</script>