<?php

namespace Sprint\Migration\Exceptions;

use Exception;

class HelperException extends Exception
{


}