<?php

namespace Sprint\Migration\Exceptions;

use Exception;

class RestartException extends Exception
{

}