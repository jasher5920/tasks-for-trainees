<?php

namespace Sprint\Migration\Exceptions;

use Exception;

class SchemaException extends Exception
{


}