<?php

namespace Sprint\Migration\Helpers;

/**
 * Class AdminIblockHelper
 * @package Sprint\Migration\Helpers
 *
 * @deprecated use UserOptionsHelper
 */
class AdminIblockHelper extends UserOptionsHelper
{

}
