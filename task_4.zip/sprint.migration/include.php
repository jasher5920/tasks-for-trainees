<?php

include(__DIR__ . '/locale/ru.php');
